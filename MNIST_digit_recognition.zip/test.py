import tensorflow as tf
from tensorflow import keras
import numpy as np
import cv2

def load_and_preprocess_image(image_path: str, target_size=(28, 28)) -> np.ndarray:
    try:
        img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        if img is None:
            print(f"Error: Could not read image at {image_path}")
            return None

        if np.mean(img) > 127:  # Simple inversion check
            img = 255 - img

        img = cv2.resize(img, target_size)
        img = img.astype('float32') / 255.0
        img = img.reshape((1,) + target_size + (1,))
        return img
    except Exception as e:
        print(f"Error processing image {image_path}: {e}")
        return None

def predict_digit(model: keras.Model, image: np.ndarray) -> int:
    prediction = model.predict(image)
    predicted_digit = np.argmax(prediction)
    return predicted_digit

def main():
    """Loads a model, processes a user-specified image, and prints the prediction."""
    model_path = 'mnist_model.keras'
    image_path = 'number.jpeg'

    try:
        model = keras.models.load_model(model_path)
    except Exception as e:
        print(f"Error loading model: {e}")
        return
    image = load_and_preprocess_image(image_path)
    if image is not None:
        prediction = predict_digit(model, image)
        print(f"Predicted digit: {prediction}")

if __name__ == "__main__":
    main()