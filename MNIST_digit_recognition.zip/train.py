import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import matplotlib.pyplot as plt
import numpy as np
import os
import random

def load_and_preprocess_data(show_examples=False, num_examples=5):
    """Loads, preprocesses, and optionally displays sample data from the MNIST dataset.

    Args:
        show_examples (bool): Whether to display sample images. Defaults to False.
        num_examples (int): The number of examples to display. Defaults to 5.

    Returns:
        tuple: A tuple containing (train_images, train_labels), (test_images, test_labels).
               - train_images:  NumPy array of shape (60000, 28, 28), type float32, values in [0, 1].
               - train_labels:  NumPy array of shape (60000,), type uint8.
               - test_images:   NumPy array of shape (10000, 28, 28), type float32, values in [0, 1].
               - test_labels:   NumPy array of shape (10000,), type uint8.
    """
    (train_images, train_labels), (test_images, test_labels) = keras.datasets.mnist.load_data()

    # Normalize pixel values to be between 0 and 1
    train_images = train_images.astype('float32') / 255.0
    test_images = test_images.astype('float32') / 255.0

    if show_examples:
        plt.figure(figsize=(10, 2))
        for i in range(num_examples):
            index = random.randint(0, len(train_images) - 1)  # Randomly select images
            plt.subplot(1, num_examples, i + 1)
            plt.imshow(train_images[index], cmap='gray')
            plt.title(f"Label: {train_labels[index]}")
            plt.axis('off')
        plt.show()

    return (train_images, train_labels), (test_images, test_labels)



def build_model(input_shape=(28, 28)):
    """Builds a convolutional neural network model for MNIST classification.

    Args:
        input_shape (tuple): The shape of the input images (height, width).

    Returns:
        keras.Model: The compiled Keras model.
    """
    model = keras.Sequential([
        # Reshape the input to be (28, 28, 1) for the Conv2D layer
        layers.Reshape(input_shape + (1,), input_shape=input_shape),

        # Convolutional layers
        layers.Conv2D(32, (3, 3), activation='relu'),  # 32 filters, 3x3 kernel
        layers.MaxPooling2D((2, 2)),                 # Downsample by factor of 2
        layers.Conv2D(64, (3, 3), activation='relu'),
        layers.MaxPooling2D((2, 2)),
        layers.Conv2D(64, (3, 3), activation='relu'), # Add another conv layer

        # Flatten the output of the convolutional layers
        layers.Flatten(),

        # Dense (fully connected) layers
        layers.Dense(64, activation='relu'),
        layers.Dense(10, activation='softmax')  # 10 output units for 10 digits (0-9)
    ])

    model.compile(optimizer='adam',
                  loss='sparse_categorical_crossentropy',  # Use sparse_categorical_crossentropy for integer labels
                  metrics=['accuracy'])

    return model

def build_simple_model(input_shape=(28,28)):
    """Builds a simple feedforward neural network model.  Much faster but less accurate."""
    model = keras.Sequential([
        layers.Flatten(input_shape=input_shape),
        layers.Dense(128, activation='relu'),
        layers.Dense(10, activation='softmax')
    ])

    model.compile(optimizer='adam',
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])
    return model


def train_model(model, train_images, train_labels, epochs=10, batch_size=32, validation_split=0.1,  callbacks=None):
    """Trains the provided model on the given data.

    Args:
        model (keras.Model): The compiled Keras model.
        train_images (np.ndarray): Training images.
        train_labels (np.ndarray): Training labels.
        epochs (int): The number of training epochs. Defaults to 10.
        batch_size (int): The batch size. Defaults to 32.
        validation_split (float): Fraction of the training data to use for validation.
        callbacks (list):  A list of keras.callbacks.Callback instances.

    Returns:
        keras.callbacks.History: The training history object.
    """
    history = model.fit(train_images, train_labels, epochs=epochs, batch_size=batch_size,
                        validation_split=validation_split, callbacks=callbacks)
    return history

def evaluate_model(model, test_images, test_labels):
    """Evaluates the model on the test data.

    Args:
        model (keras.Model): The trained Keras model.
        test_images (np.ndarray): Test images.
        test_labels (np.ndarray): Test labels.

    Returns:
        tuple: Test loss and test accuracy.
    """
    test_loss, test_acc = model.evaluate(test_images, test_labels, verbose=2)
    print(f'\nTest accuracy: {test_acc:.4f}')
    print(f'Test loss: {test_loss:.4f}')
    return test_loss, test_acc



def predict_and_display(model, test_images, test_labels, num_predictions=5):
    """Makes predictions on a few test images and displays the results.

    Args:
        model (keras.Model):  The trained model.
        test_images (np.ndarray):  The test images.
        test_labels (np.ndarray):  The true test labels.
        num_predictions (int): Number of predictions to make and display.
    """
    predictions = model.predict(test_images)

    plt.figure(figsize=(10, 2 * num_predictions))  # Adjust figure size for multiple rows
    for i in range(num_predictions):
        index = random.randint(0, len(test_images) - 1) # Randomly select images
        predicted_label = np.argmax(predictions[index])
        true_label = test_labels[index]

        plt.subplot(num_predictions, 2, 2 * i + 1)  # Two plots per image: image and probabilities
        plt.imshow(test_images[index], cmap='gray')
        plt.title(f"True: {true_label}, Predicted: {predicted_label}")
        plt.axis('off')

        plt.subplot(num_predictions, 2, 2 * i + 2)
        plt.bar(range(10), predictions[index])
        plt.xticks(range(10))
        plt.ylim([0, 1])
        plt.title("Prediction Probabilities")

    plt.tight_layout()  # Adjust layout to prevent overlapping
    plt.show()

def plot_training_history(history):
    """Plots the training and validation accuracy and loss curves."""
    plt.figure(figsize=(12, 4))

    # Plot training & validation accuracy values
    plt.subplot(1, 2, 1)
    plt.plot(history.history['accuracy'])
    plt.plot(history.history['val_accuracy'])
    plt.title('Model accuracy')
    plt.ylabel('Accuracy')
    plt.xlabel('Epoch')
    plt.legend(['Train', 'Validation'], loc='upper left')

    # Plot training & validation loss values
    plt.subplot(1, 2, 2)
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.title('Model loss')
    plt.ylabel('Loss')
    plt.xlabel('Epoch')
    plt.legend(['Train', 'Validation'], loc='upper left')

    plt.tight_layout()
    plt.show()


def save_model(model, filepath="mnist_model.h5"):
    """Saves the trained model to a file.

    Args:
        model (keras.Model): The Keras model to save.
        filepath (str): The path to save the model file. Defaults to "mnist_model.h5".
    """
    model.save(filepath)
    print(f"Model saved to {filepath}")

def load_model_from_file(filepath="mnist_model.h5"):
    """Loads a Keras model from a file.

    Args:
        filepath (str):  The path to the saved model file.

    Returns:
        keras.Model: The loaded Keras model, or None if the file doesn't exist.
    """
    if os.path.exists(filepath):
        model = keras.models.load_model(filepath)
        print(f"Model loaded from {filepath}")
        return model
    else:
        print(f"Error: Model file not found at {filepath}")
        return None



def main():
    """Main function to execute the MNIST digit recognition training."""

    # --- Load and Preprocess Data ---
    (train_images, train_labels), (test_images, test_labels) = load_and_preprocess_data(show_examples=True)

    # --- Build or Load Model ---
    model_filepath = "mnist_model.keras"  # Use .keras extension for TensorFlow 2.x+
    loaded_model = load_model_from_file(model_filepath)

    if loaded_model is None:
        # model = build_model()  # Use the CNN model (better performance)
        model = build_simple_model()  # Use a simple feedforward model (faster training)
        model.summary()  # Print model architecture

        # --- Train Model ---
        # Callbacks for early stopping and model checkpointing
        early_stopping = keras.callbacks.EarlyStopping(
            monitor='val_loss',  # Monitor validation loss
            patience=3,          # Stop after 3 epochs with no improvement
            restore_best_weights=True  # Restore the best weights
        )

        model_checkpoint = keras.callbacks.ModelCheckpoint(
            model_filepath,
            monitor='val_loss',  # Save the best model based on validation loss
            save_best_only=True, # Only save the best
            mode='min'
        )

        callbacks = [early_stopping, model_checkpoint]  # Combine callbacks

        history = train_model(model, train_images, train_labels, epochs=20, batch_size=64, validation_split=0.1, callbacks=callbacks)
        plot_training_history(history) #plot training history
        save_model(model, model_filepath)

    else:
        model = loaded_model


    # --- Evaluate Model ---
    evaluate_model(model, test_images, test_labels)

    # --- Predict and Display ---
    predict_and_display(model, test_images, test_labels)


if __name__ == "__main__":
    main()